# -*- coding: utf-8 -*-
"""
Created on Sat Nov 14 16:45:45 2020

@author: lenovo
"""
import pandas as pd
df = pd.read_csv('artists-data.csv')
df2 = pd.read_csv('lyrics-data.csv')
df2.drop_duplicates(subset = ['ALink'], keep = 'first', inplace = True) 


i = 0
while (i < len(df2['ALink'])):
    df2.iloc[i,]['ALink'] = df2.iloc[i,]['ALink'].replace('-',' ').replace('/','')
    i = i + 1


df3 = df2[df2['Idiom'] == 'ENGLISH']
df3['Genre'] = 0

n = 0
m = 0
while(n < len(df3['ALink'])):
    while(m < len(df['Artist'])):
        if(df3.iloc[n,]['ALink'] == df.iloc[m,]['Artist'].lower()):
            temp = df.iloc[m,-2]
            df3.iloc[n,-1] = temp
        m = m + 1
    m = 0
    n = n + 1

df4 = df3[(df3['Genre'] != 0) & (df3['Genre'] != 'Sertanejo') & (df3['Genre'] != 'Funk Carioca')]
df5 = df4[['Lyric','Genre']]
i = 0
for x in df5[df5['Genre'] == 'Hip Hop'].iterrows():
     #iterrows returns a tuple per record whihc you can unpack
      #X[0] is the index
     # X[1] is a tuple of the rows values so X[1][0] is the value of the first column etc.
     pd.DataFrame([x[1][0]]).to_csv('hip'+str(i)+".txt", header=False, index=False)
     i = i + 1
 
i = 0    
for x in df5[df5['Genre'] == 'Rock'].iterrows():
     #iterrows returns a tuple per record whihc you can unpack
     #X[0] is the index
     # X[1] is a tuple of the rows values so X[1][0] is the value of the first column etc.
     pd.DataFrame([x[1][0]]).to_csv('rock'+str(i)+".txt", header=False, index=False)
     i = i + 1
i = 0
for x in df5[df5['Genre'] == 'Pop'].iterrows():
     #iterrows returns a tuple per record whihc you can unpack
      #X[0] is the index
      #X[1] is a tuple of the rows values so X[1][0] is the value of the first column etc.
     pd.DataFrame([x[1][0]]).to_csv('pop'+str(i)+".txt", header=False, index=False)
     i = i + 1

