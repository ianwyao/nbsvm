# -*- coding: utf-8 -*-
"""
Created on Mon Nov  9 15:04:18 2020

@author: Ian
"""
import nltk
from sklearn import preprocessing
import pandas as pd
import sklearn
import re  
from sklearn.feature_extraction.text import CountVectorizer, TfidfVectorizer
from nltk.tokenize import word_tokenize
from nltk.probability import FreqDist
import matplotlib.pyplot as plt
from nltk.corpus import stopwords
## For Stemming
from nltk.tokenize import sent_tokenize, word_tokenize
import os
from sklearn.model_selection import train_test_split
import random as rd
from sklearn.naive_bayes import MultinomialNB
from sklearn.metrics import confusion_matrix
from sklearn.naive_bayes import BernoulliNB
from sklearn.tree import DecisionTreeClassifier
from sklearn import tree
## conda install python-graphviz
## restart kernel (click the little red x next to the Console)
import graphviz 
from sklearn.metrics import confusion_matrix
import numpy as np
import matplotlib.pyplot as plt
from sklearn.tree import DecisionTreeClassifier, plot_tree
from sklearn.svm import LinearSVC
from sklearn.decomposition import PCA
#from mpl_toolkits.mplot3d import Axes3D 
## conda install python-graphviz
## restart kernel (click the little red x next to the Console)
import graphviz 
from sklearn.metrics import confusion_matrix
from sklearn.tree import export_graphviz
#from sklearn.externals.six import StringIO  
from IPython.display import Image  
## conda install pydotplus
#import pydotplus
from sklearn.ensemble import RandomForestClassifier
from sklearn.datasets import make_classification
#from nltk.stem import WordNetLemmatizer 
#LEMMER = WordNetLemmatizer() 
from nltk.stem.porter import PorterStemmer
import string
import numpy as np



STEMMER=PorterStemmer()
def MY_STEMMER(str_input):
    words = re.sub(r"[^A-Za-z\']", " ", str_input).lower().split()
    words = [STEMMER.stem(word) for word in words]
    return words



MyVect_STEM=CountVectorizer(input='filename',
                        analyzer = 'word',
                        stop_words='english',
                        ##stop_words=["and", "or", "but"],
                        token_pattern='(?u)[a-zA-Z]+',
                        #token_pattern=pattern,
                        tokenizer=MY_STEMMER,
                        #strip_accents = 'unicode', 
                        lowercase = True
                        )



#We will be creating new data frames
FinalDF_STEM=pd.DataFrame()


## This code assumes that it is in the same folder/location
## as the folders. It will loop through the files in
## these folders and will build the list needed to use
## CounterVectorizer. 

for name in ['Alan_Walker','Eminem']: ## Charlie Puth and Alan Walker

    builder=name+"DF"
    #print(builder)
    path = name
    
    FileList=[]
    for item in os.listdir(path):
        #print(path+ "\\" + item)
        next=path+ "\\" + item
        FileList.append(next)  
        print("full list...")
        #print(FileList)
        X1=MyVect_STEM.fit_transform(FileList)
        
        ColumnNames1=MyVect_STEM.get_feature_names()
        NumFeatures1=len(ColumnNames1)

        #print("Column names: ", ColumnNames2)
        #Create a name
        
    builderS=pd.DataFrame(X1.toarray(),columns=ColumnNames1)
    ## Add column
    #print("Adding new column....")
    builderS["LABEL"]=name

    #print(builderS)
    FinalDF_STEM= FinalDF_STEM.append(builderS)

FinalDF=FinalDF_STEM.fillna(0)   




TrainDF, TestDF = train_test_split(FinalDF, test_size=0.2)

## IMPORTANT - YOU CANNOT LEAVE LABELS ON THE TEST SET
## Save labels
TestLabels=TestDF["LABEL"]
#print(TestLabels)
## remove labels
## Make a copy of TestDF
CopyTestDF=TestDF.copy()
TestDF = TestDF.drop(["LABEL"], axis=1)
print(TestDF)

## DF seperate TRAIN SET from the labels
TrainDF_nolabels=TrainDF.drop(["LABEL"], axis=1)
#print(TrainDF_nolabels)
TrainLabels=TrainDF["LABEL"]
#print(TrainLabels)




####################################################################
########################### Naive Bayes ############################
####################################################################
from sklearn.naive_bayes import MultinomialNB

MyModelNB= MultinomialNB()

MyModelNB.fit(TrainDF_nolabels, TrainLabels)
Prediction = MyModelNB.predict(TestDF)
print("\nThe prediction from NB is:")
print(Prediction)
print("\nThe actual labels are:")
print(TestLabels)


## confusion matrix
from sklearn.metrics import confusion_matrix

cnf_matrix = confusion_matrix(TestLabels, Prediction)
print("\nThe confusion matrix is:")
print(cnf_matrix)
### prediction probabilities
## columns are the labels in alphabetical order

print(np.round(MyModelNB.predict_proba(TestDF),2))

## VIS
from sklearn import metrics 
print(metrics.classification_report(TestLabels, Prediction))
print(metrics.confusion_matrix(TestLabels, Prediction))

import seaborn as sns
sns.heatmap(cnf_matrix.T, square=True, annot=True, fmt='d', 
            xticklabels=["Hip Hop", "Pop",'Rock'], yticklabels=["Hip Hop", "Pop",'Rock'])
plt.xlabel('True Label')
plt.ylabel('Predicted Label')

#SVM_Model2=sklearn.svm.SVC(C=100, kernel='rbf', 
#                           verbose=True, gamma="auto")
#SVM_Model2.fit(TRAIN, TRAIN_Labels)
#############################################
###########  SVM ############################
#############################################
from sklearn.svm import LinearSVC
SVM_Model=sklearn.svm.SVC(C=100, kernel='rbf', verbose=True, gamma="auto")
SVM_Model.fit(TrainDF_nolabels, TrainLabels)

print("SVM prediction:\n", SVM_Model.predict(TestDF))
print("Actual:")
print(TestLabels)

SVM_matrix = confusion_matrix(TestLabels, SVM_Model.predict(TestDF))
print("\nThe confusion matrix is:")
print(SVM_matrix)
print("\n\n")

fig,ax =plt.subplots(1,1)
the_table = ax.table(cellText=SVM_matrix,
                      rowLabels=['Alan_Walker','Eminem'],
                      colLabels=['Alan_Walker','Eminem'], loc = 'top'
                     )
ax.get_xaxis().set_visible(False)
ax.get_yaxis().set_visible(False)



###################################################
##
##   Visualizing the top features
##   Then Visualizing the margin with the top 2 in 2D
##
##########################################################

import matplotlib.pyplot as plt
## Credit: https://medium.com/@aneesha/visualising-top-features-in-linear-svm-with-scikit-learn-and-matplotlib-3454ab18a14d
## Define a function to visualize the TOP words (variables)
MODEL=SVM_Model; COLNAMES=TrainDF.columns; top_features=20;
    ## Model if SVM MUST be SVC, RE: SVM_Model=LinearSVC(C=10)
coef = MODEL.coef_.ravel()
top_positive_coefficients = np.argsort(coef,axis=0)[-top_features:]
print(top_positive_coefficients)
top_negative_coefficients = np.argsort(coef,axis=0)[:top_features]
print(top_negative_coefficients)
top_coefficients = np.hstack([top_negative_coefficients, top_positive_coefficients])
top_coefficients = np.array([123,128,263,290,356,392,7,387,231,394,154,82,196,234],dtype ='int64')
    # create plot
plt.figure(figsize=(15, 5))
colors = ["red" if c < 0 else "blue" for c in coef[top_coefficients]]
plt.bar(  x=  np.arange(14)  , height=coef[top_coefficients], width=.5,  color=colors)
feature_names = np.array(COLNAMES)
plt.xticks(np.arange(14), feature_names[top_coefficients], rotation=60, ha="right")
plt.show()


TRAIN= TrainDF   ## As noted above - this can also be TrainDF2, etc.
TRAIN_Labels= TrainLabels
TEST= TestDF
TEST_Labels= TestLabels


#########################################################
##  Using the top 2 features from above
## Let's look at the margin of the SVM
##################################################################
from sklearn.svm import SVC
X = np.array([TRAIN["sleep"], TRAIN["play"]])
X = X.transpose()
print(X)
#The classes of the training data
y = TrainLabels
print(y)
from sklearn.preprocessing import LabelBinarizer
from sklearn import preprocessing
lb = preprocessing.LabelBinarizer()
y=lb.fit_transform(y)

y = np.array(y)
y = y.ravel()  ## to make it the right 1D array type

print(y)


## Here - we need to make y into 0 or 1 so it will plot

#TRAIN
#Define the model with SVC
# Fit SVM with training data
clf = SVC(C=1, kernel="linear")
clf.fit(X, y) 


margin = 2 / np.sqrt(np.sum(clf.coef_ ** 2))

# get the separating hyperplane
#The weights vector w
w = clf.coef_[0]
#print("The weight vector ", w)

#The slope of the SVM sep line
a = -w[0] / w[1]
#print("The slope of the SVM sep line is ", a)

#Create a variable xx that are values between 4 and 8
xx = np.linspace(0, 10)

#Equation of sep line in 2D
# x1  = - b/w1  - (w0/w1 )(x0)
## Note that clf_intercept_[0] is "b"
## Note that a  = -w0/w1 and xx are a bunch of x values
## This is the y values for the main sep line
yy = a * xx - (clf.intercept_[0]) / w[1]

##These plot the two parellel margin lines
# plot the parallel lines to the separating hyperplane 
#that pass through the support vectors and note the margin
#margin = 2 / np.sqrt(np.sum(clf.coef_ ** 2))
#translate the location of the center sep line by
# adding or subtracting a fraaction of the margin 
yy_down = yy + .5*margin
yy_up = yy - .5*margin

# plot the line, the points, and the nearest vectors to the plane
#plt.figure(fignum, figsize=(4, 3))
plt.clf()
plt.plot(xx, yy, 'r-')
plt.plot(xx, yy_down, 'k--')
plt.plot(xx, yy_up, 'k--')

plt.scatter(clf.support_vectors_[:, 0], clf.support_vectors_[:, 1], s=10,
                facecolors='none', zorder=5)
#cmap is the color map
plt.scatter(X[:, 0], X[:, 1], c=y, zorder=5, cmap=plt.cm.Paired)

plt.axis('tight')

